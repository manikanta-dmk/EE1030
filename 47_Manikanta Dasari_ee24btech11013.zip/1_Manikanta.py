import random

def simulate_game():
    """Plays a single round of the St. Petersburg game and returns the payout."""
    flips = 1
    while random.randint(0, 1) == 0:  # Keep flipping until tails appears
        flips += 1
    return 2 ** flips  # Payout formula

def compute_average(m):
    """Simulates 'm' games and calculates the average payout."""
    payouts = [simulate_game() for _ in range(m)]
    return round(sum(payouts) / m, 3)  # Compute and round the average

# Number of simulations
num_games = [100, 10000, 1000000]
results = [compute_average(m) for m in num_games]

# Print results formatted to three decimal places
print(f"{results[0]:.3f} {results[1]:.3f} {results[2]:.3f}")
