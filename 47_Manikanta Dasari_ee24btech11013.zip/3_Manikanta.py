import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def generate_subsets(n, k, N):
    """Generate N subsets of size k from {1, 2, ..., n} using uniform samples."""
    U = np.random.rand(n, N)  # Generate n × N uniform [0,1] samples
    I = np.zeros((n, N), dtype=int)  # Initialize indicator matrix

    for j in range(N):
        remaining = k
        for i in range(n):
            threshold = remaining / (n - i)
            if U[i, j] <= threshold:
                I[i, j] = 1
                remaining -= 1
                if remaining == 0:
                    break  # Stop if we've selected k elements

    # Convert binary subsets to decimal representation
    subset_values = np.array([int("".join(I[:, j].astype(str))[::-1], 2) for j in range(N)])
    return subset_values

def plot_histogram(subset_values, n, k, N):
    """Plot histogram of subset values."""
    # Only consider valid subsets (those with exactly k elements)
    valid_subsets = []
    for val in subset_values:
        binary = bin(val)[2:].zfill(n)
        if binary.count('1') == k:
            valid_subsets.append(val)

    plt.hist(valid_subsets, bins=range(2**n + 1), edgecolor='black', alpha=0.7, density=True)
    plt.title(f"Histogram of {N} equally likely subsets of size {k} from {n}")
    plt.xlabel("Subset Decimal Representation")
    plt.ylabel("Frequency")
    plt.grid()
    plt.show()

def main():
    """Main function to read arguments, generate subsets, save results, and plot histogram."""
    if len(sys.argv) != 4:
        print("Usage: python script.py <n> <k> <N>")
        return

    try:
        n = int(sys.argv[1])
        k = int(sys.argv[2])
        N = int(sys.argv[3])
    except ValueError:
        print("Error: n, k, and N must be integers.")
        return

    if k > n or k <= 0:
        print("Error: k must be between 1 and n.")
        return

    # Generate subset values
    subset_values = generate_subsets(n, k, N)

    # Save to CSV
    output_filename = f"Subsets_n{n}_k{k}_N{N}.csv"
    pd.DataFrame(subset_values).to_csv(output_filename, index=False, header=False)
    print(f"Generated {N} subsets and saved to {output_filename}")

    # Plot histogram
    plot_histogram(subset_values, n, k, N)

if __name__ == "__main__":
    main()
