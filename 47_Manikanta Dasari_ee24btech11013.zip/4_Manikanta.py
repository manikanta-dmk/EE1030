import numpy as np
import matplotlib.pyplot as plt
import sys

def method_0(N):
    """Angle method: Randomly select an angle for the chord with a fixed endpoint at (0,1)."""
    theta = np.random.uniform(0, np.pi, N)  # Uniformly distributed angle in [0, π]
    chord_length = 2 * np.sin(theta / 2)  # Chord length formula
    
    probability = np.mean(chord_length >= np.sqrt(3))
    
    # Plot histogram
    plt.hist(chord_length, bins=int(np.sqrt(N)), edgecolor='black', alpha=0.7)
    plt.xlabel("Chord Length")
    plt.ylabel("Frequency")
    plt.title("Histogram of Chord Lengths (Method 0)")
    plt.show()
    
    print(f"Fraction of chords with length ≥ sqrt(3): {probability:.3f}")

def method_1(N):
    """Distance method: Randomly select the perpendicular distance of the chord from the circle center."""
    U = np.random.uniform(0, 1, N)  # Uniformly distributed distance from 0 to 1
    chord_length = 2 * np.sqrt(1 - U**2)  # Chord length formula

    probability = np.mean(chord_length >= np.sqrt(3))
    
    # Plot histogram
    plt.hist(chord_length, bins=int(np.sqrt(N)), edgecolor='black', alpha=0.7)
    plt.xlabel("Chord Length")
    plt.ylabel("Frequency")
    plt.title("Histogram of Chord Lengths (Method 1)")
    plt.show()
    
    print(f"Fraction of chords with length ≥ sqrt(3): {probability:.3f}")

def method_2(N):
    """Center method: Randomly select the center of the chord within the unit circle."""
    # Efficiently generate points uniformly inside the unit circle
    theta = np.random.uniform(0, 2 * np.pi, N)
    r = np.sqrt(np.random.uniform(0, 1, N))  # sqrt ensures uniform distribution
    X, Y = r * np.cos(theta), r * np.sin(theta)
    
    R = np.sqrt(X**2 + Y**2)  # Distance from circle center
    chord_length = 2 * np.sqrt(1 - R**2)  # Chord length formula
    
    probability = np.mean(chord_length >= np.sqrt(3))
    
    # Plot histogram
    plt.hist(chord_length, bins=int(np.sqrt(N)), edgecolor='black', alpha=0.7)
    plt.xlabel("Chord Length")
    plt.ylabel("Frequency")
    plt.title("Histogram of Chord Lengths (Method 2)")
    plt.show()
    
    print(f"Fraction of chords with length ≥ sqrt(3): {probability:.3f}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python bertrand.py <mode> <N>")
        sys.exit(1)

    mode = int(sys.argv[1])
    N = int(sys.argv[2])

    if mode == 0:
        method_0(N)
    elif mode == 1:
        method_1(N)
    elif mode == 2:
        method_2(N)
    else:
        print("Invalid mode! Choose 0, 1, or 2.")
