import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def generate_bernoulli(samples, p):
    bernoulli_samples = (samples < p).astype(int)
    mean_value = np.mean(bernoulli_samples)
    
    p_str = f"p{int(p*100)}" if p < 1 else f"{int(p)}p{int((p-int(p))*10)}"
    output_filename = f"Bernoulli_{p_str}.csv"
    pd.DataFrame(bernoulli_samples).to_csv(output_filename, index=False, header=False)
    print(f"Mean of Bernoulli samples: {mean_value:.3f}")

def generate_exponential(samples, lam):
    exponential_samples = -np.log(1 - samples) / lam
    lam_str = f"p{int(lam*10)}" if lam < 1 else str(lam).replace(".", "p")
    output_filename = f"Exponential_{lam_str}.csv"
    pd.DataFrame(exponential_samples).to_csv(output_filename, index=False, header=False)

    N = len(samples)
    plt.hist(exponential_samples, bins=int(np.sqrt(N)), edgecolor='black', alpha=0.7)
    plt.title(f"Exponential Distribution (λ={lam})")
    plt.xlabel("Value")
    plt.ylabel("Frequency")
    plt.grid()
    plt.show()

def generate_custom_X(samples):
    x_samples = []
    for u in samples:
        if u <= 1/3:
            x = np.sqrt(3 * u)
        elif 1/3 < u <= 2/3:
            x = 2  # Fixed value for this range
        else:
            x = 6 * u - 2
        x_samples.append(x)

    x_samples = np.array(x_samples)
    pd.DataFrame(x_samples).to_csv("CDFX.csv", index=False, header=False)

    count_2 = np.sum(x_samples == 2)
    print(f"Number of times 2 appears in samples: {count_2}")

    N = len(samples)
    plt.hist(x_samples, bins=int(np.sqrt(N)), edgecolor='black', alpha=0.7)
    plt.title("Histogram of X samples")
    plt.xlabel("Value")
    plt.ylabel("Frequency")
    plt.grid()
    plt.show()

def main():
    if len(sys.argv) < 3:
        print("Usage: python script.py <mode> <filename> [parameter]")
        return

    mode = int(sys.argv[1])
    filename = sys.argv[2]

    try:
        uniform_samples = pd.read_csv(filename, header=None, skiprows=1).squeeze().astype(float)
    except Exception as e:
        print(f"Error reading file: {e}")
        return

    if mode == 0:
        if len(sys.argv) < 4:
            print("Error: Mode 0 requires parameter p")
            return
        p = float(sys.argv[3])
        generate_bernoulli(uniform_samples, p)
    elif mode == 1:
        if len(sys.argv) < 4:
            print("Error: Mode 1 requires parameter λ")
            return
        lam = float(sys.argv[3])
        generate_exponential(uniform_samples, lam)
    elif mode == 2:
        generate_custom_X(uniform_samples)
    else:
        print("Invalid mode. Use 0, 1, or 2.")

if __name__ == "__main__":
    main()
